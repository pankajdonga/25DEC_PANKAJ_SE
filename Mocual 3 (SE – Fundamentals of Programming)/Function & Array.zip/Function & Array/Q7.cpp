//Q.7 WAP Find out length of string without using inbuilt function

#include<stdio.h>
main()
{
	char str[100];
	int i,j=0,k;
	
	printf("Enetr String= ");
	scanf("%s", &str);
	
	for (i=0; i<str[i]; i++)
	{
	
	}
	printf("Length Of [%s] Is= %d", str, i);
}

